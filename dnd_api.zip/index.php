<?php include 'index.html';?>
<?php
//phpinfo();
?>